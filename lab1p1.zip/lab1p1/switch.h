#ifndef SWITCH_H
#define SWITCH_H
//
//#define SW1 PORTDbits.RD6
//#define PRESSED 0
//#define RELEASED 1

void initSW();

#endif